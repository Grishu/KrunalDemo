package com.demoproject.activites;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.demoproject.R;
import com.demoproject.asynctask.AsyncTaskForNetworkManager;
import com.demoproject.interfaces.ResponseListener;
import com.demoproject.model.WebserviceModel;
import com.demoproject.model.WebserviceModelResponse;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.RequestBody;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ResponseListener {


    RecyclerView recyclerView;
    List<WebserviceModel> webserviceModels = new ArrayList<>();
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        customAdapter = new CustomAdapter(webserviceModels);
        recyclerView.setAdapter(customAdapter);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        callWebservice();
    }

    public void callWebservice() {
        new AsyncTaskForNetworkManager(this, this, generateJSONForWebService()).execute();
    }

    public RequestBody generateJSONForWebService() {
        final FormEncodingBuilder builder = new FormEncodingBuilder();
        builder.addEncoded("key", "454545454");
        return builder.build();
    }

    @Override
    public void onResponse(Object object) {
        WebserviceModelResponse webserviceModelResponse = (WebserviceModelResponse) object;
        webserviceModels.clear();
        webserviceModels.addAll(webserviceModelResponse.getWebserviceModels());
        customAdapter.notifyDataSetChanged();
    }
}
