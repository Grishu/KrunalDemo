package com.demoproject.model;

import java.util.List;


public class WebserviceModelResponse {

    private List<WebserviceModel> webserviceModels;


    public List<WebserviceModel> getWebserviceModels() {
        return webserviceModels;
    }

    public void setWebserviceModels(List<WebserviceModel> webserviceModels) {
        this.webserviceModels = webserviceModels;
    }
}
