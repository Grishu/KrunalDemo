package com.demoproject.interfaces;

public interface ResponseListener {

     void onResponse(Object object);
}
