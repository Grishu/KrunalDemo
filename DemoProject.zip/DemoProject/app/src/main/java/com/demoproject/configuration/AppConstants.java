package com.demoproject.configuration;

public class AppConstants {

    public static final String URL = "Enter URL Here";



}
